const storage = require('../../utils/storage');

function blankForm() {
  return {
    title: '',
    description: '',
    coverImage: '',
    categoryId: 'all',
    cookingTime: '',
    difficulty: '简单',
    servings: '',
    ingredients: [{ id: 'ing_' + Date.now(), name: '', amount: '' }],
    steps: [{ id: 'step_' + Date.now(), order: 1, description: '', image: '' }],
    tips: '',
    tags: [],
    sourceUrl: '',
    sourceType: 'manual',
    isFavorite: false
  };
}

Page({
  data: {
    id: '',
    form: blankForm(),
    categories: [],
    categoryNames: [],
    categoryIndex: 0,
    selectedCategoryName: '全部',
    difficulties: ['简单', '中等', '困难'],
    difficultyIndex: 0,
    selectedDifficulty: '简单',
    tagText: '',
    saving: false
  },
  onLoad(query) {
    const categories = storage.getCategories();
    const source = query.draft ? JSON.parse(decodeURIComponent(query.draft)) : null;
    const existing = query.id ? storage.getRecipeById(query.id) : null;
    const form = existing || Object.assign(blankForm(), source || {});
    const categoryIndex = Math.max(0, categories.findIndex(item => item.id === form.categoryId));
    const difficultyIndex = Math.max(0, ['简单', '中等', '困难'].indexOf(form.difficulty));
    this.setData({
      id: query.id || '',
      form,
      categories,
      categoryNames: categories.map(item => item.name),
      categoryIndex,
      selectedCategoryName: categories[categoryIndex].name,
      difficultyIndex,
      selectedDifficulty: ['简单', '中等', '困难'][difficultyIndex],
      tagText: (form.tags || []).join('，')
    });
  },
  input(e) {
    const form = Object.assign({}, this.data.form);
    form[e.currentTarget.dataset.field] = e.detail.value;
    this.setData({ form });
  },
  inputTags(e) {
    const form = Object.assign({}, this.data.form, { tags: e.detail.value.split(/[，,]/).map(item => item.trim()).filter(Boolean) });
    this.setData({ form, tagText: e.detail.value });
  },
  pickCategory(e) {
    const index = Number(e.detail.value);
    const form = Object.assign({}, this.data.form, { categoryId: this.data.categories[index].id });
    this.setData({ form, categoryIndex: index, selectedCategoryName: this.data.categories[index].name });
  },
  pickDifficulty(e) {
    const index = Number(e.detail.value);
    const form = Object.assign({}, this.data.form, { difficulty: this.data.difficulties[index] });
    this.setData({ form, difficultyIndex: index, selectedDifficulty: this.data.difficulties[index] });
  },
  changeIngredients(e) {
    this.setData({ form: Object.assign({}, this.data.form, { ingredients: e.detail.items }) });
  },
  changeSteps(e) {
    this.setData({ form: Object.assign({}, this.data.form, { steps: e.detail.items }) });
  },
  chooseCover() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: res => this.setData({ form: Object.assign({}, this.data.form, { coverImage: res.tempFiles[0].tempFilePath }) }),
      fail: () => wx.showToast({ title: '已取消选择图片', icon: 'none' })
    });
  },
  validate() {
    const form = this.data.form;
    if (!form.title.trim()) return '菜谱名称必填';
    if (!form.categoryId) return '分类必填';
    if (!form.ingredients.some(item => item.name.trim())) return '至少填写一个食材';
    if (!form.steps.some(item => item.description.trim())) return '至少填写一个步骤';
    return '';
  },
  save() {
    if (this.data.saving) return;
    const message = this.validate();
    if (message) {
      wx.showToast({ title: message, icon: 'none' });
      return;
    }
    this.setData({ saving: true });
    const form = Object.assign({}, this.data.form, {
      ingredients: this.data.form.ingredients.filter(item => item.name.trim()),
      steps: this.data.form.steps.filter(item => item.description.trim()).map((item, index) => Object.assign({}, item, { order: index + 1 }))
    });
    const saved = this.data.id ? storage.updateRecipe(this.data.id, form) : storage.saveRecipe(form);
    this.setData({ saving: false });
    if (!saved) {
      wx.showToast({ title: '保存失败', icon: 'none' });
      return;
    }
    wx.redirectTo({ url: '/pages/recipe-detail/index?id=' + saved.id });
  }
});
