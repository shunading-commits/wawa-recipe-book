const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const errors = [];
const warnWords = ['荔枝肉', '猪肚汤', '红烧肉', '购物车', '库存', '充值', '积分', '订单', '付费', '商家'];
const builtinTags = new Set(['view', 'text', 'scroll-view', 'button', 'input', 'textarea', 'picker', 'image']);

function readJson(file) {
  try {
    return JSON.parse(fs.readFileSync(path.join(root, file), 'utf8'));
  } catch (error) {
    errors.push(`${file} 不是有效 JSON`);
    return null;
  }
}

function exists(file) {
  return fs.existsSync(path.join(root, file));
}

function walk(dir, suffix) {
  const full = path.join(root, dir);
  if (!fs.existsSync(full)) return [];
  return fs.readdirSync(full).flatMap(name => {
    const file = path.join(full, name);
    return fs.statSync(file).isDirectory()
      ? walk(path.relative(root, file), suffix)
      : file.endsWith(suffix) ? [path.relative(root, file)] : [];
  });
}

function checkWxml(file) {
  const text = fs.readFileSync(path.join(root, file), 'utf8').replace(/<!--([\s\S]*?)-->/g, '');
  const stack = [];
  for (const match of text.matchAll(/<\/?([a-zA-Z0-9-]+)(?:\s[^>]*)?>/g)) {
    const full = match[0];
    const tag = match[1];
    if (full.startsWith('</')) {
      const last = stack.pop();
      if (last !== tag) errors.push(`${file} 标签闭合异常：期待 </${last}>，实际 </${tag}>`);
    } else if (!full.endsWith('/>')) {
      stack.push(tag);
    }
  }
  if (stack.length) errors.push(`${file} 存在未闭合标签：${stack.join(', ')}`);
}

function checkComponents(file) {
  const jsonFile = file.replace(/\.wxml$/, '.json');
  const json = exists(jsonFile) ? readJson(jsonFile) : {};
  const registered = new Set(Object.keys((json && json.usingComponents) || {}));
  const text = fs.readFileSync(path.join(root, file), 'utf8');
  for (const match of text.matchAll(/<([a-z][a-z0-9-]*)\b/g)) {
    const tag = match[1];
    if (tag.includes('-') && !builtinTags.has(tag) && !registered.has(tag)) {
      errors.push(`${file} 使用了未注册组件：${tag}`);
    }
  }
}

function checkRequires(file) {
  const text = fs.readFileSync(path.join(root, file), 'utf8');
  for (const match of text.matchAll(/require\(['"]([^'"]+)['"]\)/g)) {
    const target = path.resolve(path.dirname(path.join(root, file)), match[1]) + '.js';
    if (!fs.existsSync(target)) errors.push(`${file} require 路径不存在：${match[1]}`);
  }
}

const app = readJson('app.json');
readJson('project.config.json');
readJson('sitemap.json');

if (app) {
  for (const page of app.pages || []) {
    for (const ext of ['js', 'json', 'wxml', 'wxss']) {
      const file = `${page}.${ext}`;
      if (!exists(file)) errors.push(`app.json 注册页面缺少文件：${file}`);
    }
  }
  for (const item of (app.tabBar && app.tabBar.list) || []) {
    if (!(app.pages || []).includes(item.pagePath)) errors.push(`tabBar 页面未注册：${item.pagePath}`);
    for (const icon of [item.iconPath, item.selectedIconPath]) {
      if (!exists(icon)) errors.push(`tabBar 图标不存在：${icon}`);
    }
  }
}

for (const file of walk('pages', '.json').concat(walk('components', '.json'))) readJson(file);
for (const file of walk('pages', '.wxml').concat(walk('components', '.wxml'))) {
  checkWxml(file);
  checkComponents(file);
}
for (const file of ['app.js'].concat(walk('pages', '.js'), walk('components', '.js'), walk('utils', '.js'))) {
  checkRequires(file);
  new Function(fs.readFileSync(path.join(root, file), 'utf8'));
}

const defaultData = fs.readFileSync(path.join(root, 'utils/defaultData.js'), 'utf8');
if (!/const recipes = \[\];/.test(defaultData)) errors.push('utils/defaultData.js 中 recipes 必须为空数组');

const sourceFiles = ['app.js', 'app.json', 'app.wxss', 'README.md']
  .concat(walk('pages', ''), walk('components', ''), walk('utils', ''));
for (const file of sourceFiles) {
  if (!fs.statSync(path.join(root, file)).isFile()) continue;
  const text = fs.readFileSync(path.join(root, file), 'utf8');
  for (const word of warnWords) {
    if (text.includes(word) && file !== 'README.md') errors.push(`${file} 出现不应包含的词：${word}`);
  }
}

if (errors.length) {
  console.error(errors.join('\n'));
  process.exit(1);
}

console.log('蛙蛙电子菜谱自检通过');
