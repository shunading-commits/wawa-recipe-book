const storage = require('../../utils/storage');

Page({
  data: {
    keyword: '',
    history: [],
    results: [],
    searched: false
  },
  onShow() {
    this.setData({ history: storage.getSearchHistory() });
  },
  input(e) {
    this.setData({ keyword: e.detail.value });
  },
  search() {
    const keyword = this.data.keyword.trim();
    if (!keyword) {
      wx.showToast({ title: '请输入搜索内容', icon: 'none' });
      return;
    }
    this.setData({
      history: storage.saveSearchHistory(keyword),
      results: storage.searchRecipes(keyword),
      searched: true
    });
  },
  useHistory(e) {
    this.setData({ keyword: e.currentTarget.dataset.value }, this.search);
  },
  clearAll() {
    this.setData({ history: storage.clearSearchHistory() });
  },
  removeHistory(e) {
    this.setData({ history: storage.clearSearchHistory(e.currentTarget.dataset.value) });
  },
  openRecipe(e) {
    wx.navigateTo({ url: '/pages/recipe-detail/index?id=' + e.detail.id });
  },
  favorite(e) {
    storage.toggleFavorite(e.detail.id);
    if (this.data.searched) this.search();
  }
});
