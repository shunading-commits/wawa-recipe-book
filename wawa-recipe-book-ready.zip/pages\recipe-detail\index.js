const storage = require('../../utils/storage');

Page({
  data: {
    id: '',
    recipe: null,
    categoryName: '',
    confirming: false
  },
  onLoad(query) {
    this.setData({ id: query.id || '' });
  },
  onShow() {
    this.load();
  },
  onShareAppMessage() {
    const recipe = this.data.recipe;
    return {
      title: recipe ? recipe.title : '蛙蛙电子菜谱',
      path: recipe ? '/pages/recipe-detail/index?id=' + recipe.id : '/pages/menu/index'
    };
  },
  load() {
    const recipe = storage.getRecipeById(this.data.id);
    const category = recipe && storage.getCategories().find(item => item.id === recipe.categoryId);
    this.setData({ recipe, categoryName: category ? category.name : '未分类' });
  },
  toggleFavorite() {
    storage.toggleFavorite(this.data.id);
    this.load();
  },
  edit() {
    wx.navigateTo({ url: '/pages/recipe-edit/index?id=' + this.data.id });
  },
  askDelete() {
    this.setData({ confirming: true });
  },
  closeConfirm() {
    this.setData({ confirming: false });
  },
  deleteRecipe() {
    storage.deleteRecipe(this.data.id);
    wx.showToast({ title: '已删除', icon: 'success' });
    wx.switchTab({ url: '/pages/menu/index' });
  },
  goHome() {
    wx.switchTab({ url: '/pages/menu/index' });
  }
});
