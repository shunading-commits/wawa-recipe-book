const importer = require('../../utils/importer');

Page({
  data: {
    url: '',
    loading: false,
    result: null,
    failed: false
  },
  inputUrl(e) {
    this.setData({ url: e.detail.value });
  },
  parse() {
    if (!this.data.url.trim()) {
      wx.showToast({ title: '请先输入链接', icon: 'none' });
      return;
    }
    this.setData({ loading: true, result: null, failed: false });
    setTimeout(() => {
      const parsed = importer.parseRecipeUrl(this.data.url);
      this.setData({ loading: false, result: parsed.success ? parsed.data : null, failed: !parsed.success });
      if (!parsed.success) wx.showToast({ title: parsed.message, icon: 'none' });
    }, 500);
  },
  editAndSave() {
    const draft = encodeURIComponent(JSON.stringify(this.data.result));
    wx.navigateTo({ url: '/pages/recipe-edit/index?draft=' + draft });
  },
  manual() {
    wx.navigateTo({ url: '/pages/recipe-edit/index' });
  }
});
