Component({
  properties: {
    recipe: Object
  },
  methods: {
    open() {
      this.triggerEvent('open', { id: this.data.recipe.id });
    },
    favorite() {
      this.triggerEvent('favorite', { id: this.data.recipe.id });
    },
    order() {
      this.triggerEvent('order', { id: this.data.recipe.id });
    }
  }
});
