const storage = require('../../utils/storage');

Page({
  data: {
    recipeCount: 0,
    categoryCount: 0,
    favoriteCount: 0,
    confirming: false
  },
  onShow() {
    const recipes = storage.getRecipes();
    this.setData({
      recipeCount: recipes.length,
      categoryCount: storage.getCategories().length,
      favoriteCount: recipes.filter(item => item.isFavorite).length
    });
  },
  goCategories() {
    wx.navigateTo({ url: '/pages/category-manage/index' });
  },
  askClear() {
    this.setData({ confirming: true });
  },
  closeConfirm() {
    this.setData({ confirming: false });
  },
  clearData() {
    storage.resetLocalData();
    this.closeConfirm();
    this.onShow();
    wx.showToast({ title: '已清除缓存', icon: 'success' });
  }
});
