Component({
  properties: {
    small: Boolean
  }
});
